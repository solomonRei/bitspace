<?php
namespace App\Traits;

trait User {
    // in the further will be finished
}
