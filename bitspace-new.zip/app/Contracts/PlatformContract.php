<?php
namespace App\Contracts;

interface PlatformContract
{
    public function create(array $data, int $id);

}
