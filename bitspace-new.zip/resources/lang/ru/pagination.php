<?php

return [
    'next'     => 'Вперёд &raquo;',
    'previous' => '&laquo; Назад',
];
