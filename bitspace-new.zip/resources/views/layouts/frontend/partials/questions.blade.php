<div class="callback-line_block mt-0 mt-md-50">
    <div class="block-container">
        <div class="container">
            <div class="title medium center">
                Остались вопросы? Оставьте заявку на консультацию
            </div>
            <div class="block-content">
                <form action="">
                    <div class="form-groups">
                        <div class="form-control">
                            <input type="text" placeholder="Ваше имя">
                        </div>
                        <div class="form-control">
                            <input type="text" placeholder="E-mail">
                        </div>
                        <div class="form-control">
                            <input type="text" placeholder="+7 (___) ___ ___ __">
                        </div>
                    </div>
                    <button class="button primary">
                        Искать
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
