
<li>
    <a href="{{ route('filter.all', ['category' => 127]) }}">
        {{ __('custom.menu_specialists') }}
    </a>
</li>
<li>
    <a href="#">
        {{ __('custom.menu_services') }}
    </a>
</li>
<li>
    <a href="{{ route('blog.index.show') }}">
        {{ __('custom.menu_blog') }}
    </a>
</li>
<li>
    <a href="{{ route('about') }}">
        {{ __('custom.menu_about') }}
    </a>
</li>
