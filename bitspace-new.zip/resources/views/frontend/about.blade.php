@extends('layouts.frontend.app')
@section('content')
    <div class="about-us-block">
        <div class="container">
            <div class="title medium">
                О нас
            </div>
            <div class="mt-20" id="breadcrumbs">
                <ul>
                    <li>
                        <a href="#">
                            Главная
                        </a>
                    </li>
                    <li>
                        О нас
                    </li>
                </ul>
            </div>
            <div class="mt-10">
                <div class="article-image">
                    <img src="images/pages/articles/article.jpg" alt="">
                </div>
                <div class="info">
                    <div class="title small">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit
                    </div>
                    <div class="text mt-30">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                            commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim
                            id est laborum.
                        </p>
                        <p>
                            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                            Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                        </p>
                    </div>
                    <div class="contacts">
                        <a href="tel: " class="contact-phone">
                            <span>+3 (333) 333-33-33 </span>
                        </a>
                        <a href="tel: " class="contact-phone">
                            <span>+3 (333) 333-33-33 </span>
                        </a>
                        <div class="contact-address">
									<span>
										Uenimadminim <br>
										 veniam, quis nostrud exercitation
									</span>
                        </div>
                        <div class="contact-map">
                            <iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3Ae9c10c2826c5f394a40faad5c07b70d402f9d7c04bfe05df5e93a75c20be3cad&amp;source=constructor" width="100%" height="100%" frameborder="0"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
